<?
header("Location: / ");
?>