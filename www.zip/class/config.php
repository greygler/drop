<?
/* * * * * * * * * * * * * * * * * * * * * * * 
 *        Configuration for fb_bot:          *
 *                my-bot.xyz                 *
 *   Last edition by 10.05.2017, 06:13:25    *
 * * * * * * * * * * * * * * * * * * * * * * */

define('BOT_NAME', 'fb_bot'); 	// Имя бота
define('BOT_LOGO', ''); 	// Логотип бота
define('NAME_SERVER', 'my-bot.xyz'); 	// Доменное имя бота
define('HTTP_SERVER', 'http://my-bot.xyz/'); 	// Доменное имя бота с http
define('HTTPS_SERVER', 'https://my-bot.xyz/');	// Доменное имя бота с https
define('BOT_ID', '1533906063310668'); 	// ID бота
define('BOT_FILE', 'fb_bot.php'); 	// Имя основного файла Бота
define('ABS_DIR', '/home/mybot/my-bot.xyz/www/'); 	// Абсолютный путь к каталогу сайта
define('DIR', 'fb_bot/'); 	// Основная папка бота
define('DIR_FILE', 'files/'); 	// Имя папки с файлами для отправки
define('DIR_IMAGES', 'images/'); 	// Имя папки с рисунками для отправки
define('DIR_VIDEO', 'video/'); 	// Имя папки с видео-файлами (mpeg4) для отправки
define('DIR_AUDIO', 'audio/'); 	// Имя папки с аудио-файлами (mp3) для отправки
define('DIR_USERS_PIC', 'users_pic/'); 	// Имя папки с аватарами пользователей
define('VERIFY_TOKEN', 'This_is_my_bot'); 	// Токен проверки WebHook
define('TOKEN', 'EAALO7OCEyGIBABqOueTjGOZA83w1qHPxgJOmwqZBHBUf5b99C7DOhYRZCcpolZAtqgUGZAZBCrC4ctlAIueuZC6ZCfYLOfUY6n5n02DWxgiadJOZAlxI2AW2MKPYVYkHL9Gm6CBZBEzvQdsWGmJdvwu1vIeXWFeyqVVuY4HpZBnx0jAmQZDZD'); 	// Маркер доступа к станице
define('DB_HOST', 'mybot.mysql.ukraine.com.ua'); 	// Адрес базы данных, может называться localhost
define('DB_NAME', 'mybot_fbbot'); 	// Название базы данных
define('DB_LOGIN', 'mybot_fbbot'); 	// Логин базы данных
define('DB_PASS', 'tsxgcl3f'); 	// Пароль базы данных
define('SMTP_USERNAME', ''); 	// Адрес почтового ящика
define('SMTP_PORT', '465'); 	// SMTP порт
define('SMTP_HOST', 'ssl://'); 	// SMTP сервер для отправки почты
define('SMTP_PASSWORD', ''); 	// Пароль SMTP сервера
define('SMTP_CHARSET', 'utf-8'); 	// кодировка сообщений. (windows-1251 или utf-8, и т.д.)

/* * * * * * * * * * * * * * * * * * * * * * * 
 *             Created by fb_bot             *
 *          Powered by Igor Sayutin          *
 *          http://it-senior.pp.ua           *
 * * * * * * * * * * * * * * * * * * * * * * */

?>
