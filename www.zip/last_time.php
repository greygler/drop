<?
	// Обновление 16.06.2017 14:27:36, Пользователь id:1, Игорь
	define('LAST_TIME_PRODUCT','1497612454');
	define('LAST_TIME_CATEGORY','1497612456');
?>