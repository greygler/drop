<div class="comingcontainer">
    <div class="checkbacksoon">
		<p>
			<span class="go3d">4</span>
			<span class="go3d">0</span>
			<span class="go3d">3</span>
			<span class="go3d">!</span>
			
		</p>
        
        <p>
		<strong>Доступ к ресурсу запрещен.</strong></br>(получен код 403 Forbidden)</p>
		
       
    
	</div>
</div>

