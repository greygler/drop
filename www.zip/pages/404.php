<div class="comingcontainer">
    <div class="checkbacksoon">
		<p>
			<span class="go3d">4</span>
			<span class="go3d">0</span>
			<span class="go3d">4</span>
			<span class="go3d">!</span>
			
		</p>
        
        <p>
		<strong>Такая страница не существует.</strong></br>Воспользуйтесь формой поиска для нужного товара:</p>
		<form action="" method="post" class="search">
  <input type="search" name="" placeholder="поиск" class="input" />
  <input type="submit" name="" value="" class="submit" />
</form>
       
    
	</div>
</div>

