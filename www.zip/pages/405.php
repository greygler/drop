<div class="comingcontainer">
    <div class="checkbacksoon">
		<p>
			<span class="go3d">4</span>
			<span class="go3d">0</span>
			<span class="go3d">5</span>
			<span class="go3d">!</span>
			
		</p>
        
        <p>
		<strong>Недопустимый метод.</strong></br>Метод, определенный в строке запроса (Request-Line), не дозволено применять для указанного ресурса (получен код 405 Method Not Allowed)</p>
		
       
    
	</div>
</div>

