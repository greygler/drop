<div class="comingcontainer">
    <div class="checkbacksoon">
		<p>
			<span class="go3d">4</span>
			<span class="go3d">1</span>
			<span class="go3d">4</span>
			<span class="go3d">!</span>
			
		</p>
        
        <p>
		<strong>Недопустимая длина URI запроса.</strong></br>Сервер отказывается обслуживать запрос, потому что запрашиваемый URI (Request-URI) длиннее, чем сервер может интерпретировать (получен код 414 Request-URI Too Long)</p>
		
       
    
	</div>
</div>

