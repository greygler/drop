<div class="page-header lead">
		<h1><small class="text_white">Настройки </small></h1>
</div>

